# Starter Kit AI Coach Yoi (bonus pakej Advance)

Ini fail sebenar yang saya guna setiap hari dalam bisnes saya, dikemas supaya awak boleh guna terus dengan Claude Code.

## 01 - Skill Video Edit Pro
Claude edit video talking-head awak: buang pause dan bahagian tak penting, caption 3D perkataan demi perkataan, kad grafik, zoom, kesan bunyi dan CTA.
Mula di `01-Skill-Video-Edit-Pro/PANDUAN-SETUP.md`.

## 02 - Skill Semak Iklan Meta
Claude buka Ads Manager, semak setiap iklan, tutup yang bakar duit ikut peraturan awak, dan lapor pemenang. Boleh dijadualkan setiap 2 jam.
Mula di `02-Skill-Semak-Iklan-Meta/SKILL.md` (isi bahagian TETAPAN SAYA dulu).

## Keperluan
- Claude Code (rujuk ebook "Setup VS Code + Claude Code").
- Skill 02 perlukan extension Claude in Chrome.
- MacBook atau Windows.

Tersangkut? Tanya dalam group Telegram pembeli, sertakan screenshot.
