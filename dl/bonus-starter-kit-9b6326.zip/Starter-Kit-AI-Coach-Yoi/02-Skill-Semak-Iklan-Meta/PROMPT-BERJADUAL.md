# Jalankan semakan setiap 2 jam (autopilot)

Dalam Claude Code (sesi kekal terbuka), taip:

```
/loop 2h /semak-iklan-meta
```

Atau minta terus:

> Setiap 2 jam dari 9 pagi hingga 11 malam, jalankan skill semak-iklan-meta. Lapor kepada saya hanya bila ada iklan ditutup, jualan baru atau pemenang.

Nota:
- Tugas berjadual hidup selagi sesi Claude Code terbuka (dan tamat sendiri selepas 7 hari). Buka sesi baru → minta semula.
- Mula-mula, jalankan sekali secara manual dan perhatikan Claude buat setiap langkah, supaya awak yakin peraturan diikut.
- Claude tidak akan masukkan kata laluan atau maklumat kad. Log masuk Ads Manager sendiri dalam Chrome.
