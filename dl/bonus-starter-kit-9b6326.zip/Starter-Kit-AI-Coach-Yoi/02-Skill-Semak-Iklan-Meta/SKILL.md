---
name: semak-iklan-meta
description: Semak iklan Meta (FB/IG/Threads) dalam Ads Manager, tutup iklan yang bakar duit ikut peraturan, laporkan pemenang. Guna bila saya minta "semak iklan", "report ads", atau bila dijalankan secara berjadual.
---

# Semak Iklan Meta (Starter Kit Coach Yoi)

Balas dalam Bahasa Melayu, ringkas. Guna Claude in Chrome (Ads Manager mesti dah log masuk dalam Chrome saya).

## TETAPAN SAYA (isi sekali, ubah bila perlu)
- ID akaun iklan: `act=XXXXXXXXXXXXXXX`
- Kempen untuk dipantau (nama mengandungi): `Sales`, `Creative Test`, `Retargeting`
- Tarikh mula kempen: `YYYY-MM-DD`
- Harga produk: `RMxx` → CPA maksimum: `RMxx` (biasanya ≈ 50-75% harga produk, ikut margin)
- Had belanja ujian: `RM40` (belanja minimum sebelum iklan dinilai)
- Sasaran ROAS: `3`

## Langkah
1. Buka `https://adsmanager.facebook.com/adsmanager/manage/ads?act=<ID>&date=<tarikh mula>_<esok>` (data LIFETIME), tapis ikut nama kempen di atas.
2. Bagi setiap iklan **ACTIVE**, catat: belanja, purchase, CPA, link clicks, CTR (link), CPC (link).
   Jadual lebar: tarik scrollbar mendatar di bawah jadual untuk nampak lajur kanan.
3. **Peraturan TUTUP** (ikut tepat, jangan teka):
   - Belanja ≥ had ujian DAN 0 purchase → OFF.
   - Belanja ≥ had ujian DAN CPA > CPA maksimum → OFF.
   - Belanja < had ujian → BIARKAN, data belum cukup.
4. **Pemenang** (iklan ujian): ≥1 purchase, CPA < maksimum, belanja ≥ had ujian → LAPOR dan cadang salin ke kempen Sales. Jangan salin sendiri tanpa OK saya.
5. **JANGAN**: ubah bajet, ON semula iklan yang OFF, atau padam apa-apa tanpa OK saya.
6. **Lapor**:
   - Jika ada iklan ditutup, jualan baru atau pemenang: jadual ringkas (iklan | belanja | purchase | CPA | CTR | CPC) + 1-2 baris kesimpulan.
   - Jika tiada apa berubah: satu baris sahaja.

## Cara baca nombor
- CTR (link) < 1% → hook/kreatif lemah, orang tak berhenti.
- CTR tinggi tapi tiada purchase → masalah salepage/harga/tawaran, bukan iklan.
- CPC tinggi (> RM3 untuk produk digital murah) → audience terlalu sempit atau kreatif tak menarik.
- Meta boleh belanja sampai 75% lebih dari bajet harian pada hari tertentu; purata mingguan tetap ikut bajet. Itu normal.
