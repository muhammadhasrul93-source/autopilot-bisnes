---
name: video-edit-pro
description: Edit video talking-head (TikTok/Reels) secara profesional - buang pause & bahagian tak penting, caption 3D perkataan demi perkataan, kad motion graphic, carta, zoom, SFX dan CTA. Guna bila saya minta "edit video", "buang pause", "caption 3D" atau "buat professional".
---

# Video Edit Pro (Starter Kit Coach Yoi)

Balas dalam Bahasa Melayu. Jangan tanya "proceed?" - terus buat dan tunjuk hasil.
Folder kerja: `video-editing/` (ada `engine/`, `transcribe.py`, `projects/`).

## Langkah
1. **Ambil video** yang saya bagi (atau terbaru dalam folder yang saya sebut). Salin ke `projects/<nama>/`.
2. **Semak**: `bin/ffmpeg -i VIDEO`. Video iPhone biasanya HDR (HLG) - tukar ke SDR supaya warna tak pudar:
   `bin/ffmpeg -i IN -map 0:v -map 0:a -vf "zscale=t=linear:npl=203,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p,eq=contrast=1.06:saturation=1.12" -c:v libx264 -crf 16 -c:a aac base_sdr.mp4`
   Video Android/SDR: cukup `bin/ffmpeg -i IN -c:v libx264 -crf 16 -c:a aac base_sdr.mp4`.
3. **Transkrip** (BM, masa setiap perkataan):
   `bin/ffmpeg -i IN -vn -ac 1 -ar 16000 audio.wav`
   `venv/bin/python transcribe.py audio.wav transcript_raw.json small`
   Betulkan ejaan yang Whisper silap (slang, nama produk): tulis satu ayat betul bagi setiap segmen dalam `fixed_text.json`, kemudian
   `venv/bin/python engine/fix_transcript.py transcript_raw.json fixed_text.json transcript.json`. Kekalkan gaya cakap asal saya.
4. **Buang bahagian tak penting**: baca transcript.json, senaraikan julat untuk dibuang (salah sebut, ayat berulang, "emm", "apa nama", senyap lama, masa kosong di awal/akhir) dalam `projects/<nama>/drop.json` sebagai `[[mula,tamat],...]`. Jangan potong hook, isi utama dan CTA. Jangan potong di tengah perkataan.
5. **Tulis spec.json** (contoh: `projects/contoh/spec.json`):
   - `title` = hook 2.5 saat pertama.
   - Kad grafik ikut apa yang dicakap: `check` (senarai ✓), `stat` (nombor + cincin), `bar`, `line`, `cta`. **Setiap nombor mesti dari sumber sebenar (`src`). Jangan reka data.**
   - `zooms` (punch-in; `hit:true` = bunyi bass), `keywords` (perkataan bercahaya kuning), `handle` akaun saya.
   - Caption di paras dada (`caption_y` ≈1250). Kad grafik di ruang atas kepala (`y` ≈400).
6. **Potong senyap + drop.json**:
   `venv/bin/python engine/cut_silence.py projects/<nama> projects/<nama>_v2 -32 0.2 0.05 0.08 0.4`
   (Kalau bunyi bising, contoh dalam kereta, guna -27 bukan -32.) Render dari folder `_v2`.
7. **Preview**: `venv/bin/python engine/render.py projects/<nama>_v2 0 5` → `preview.mp4`. Ambil satu frame, semak bertindih atau tidak.
8. **Render penuh**: `venv/bin/python engine/render.py projects/<nama>_v2` → `final.mp4`.
9. **Lapor**: apa yang dibuang, tempoh baru, dan dakwaan/angka mana yang saya perlu semak.

## Gaya
- Caption 2-3 perkataan sekali, perkataan aktif kuning, kata kunci bercahaya.
- Setiap kad ≥3 saat. Akhiri dengan CTA.
- Tip: bila cakap pasal kerja yang AI buat, potong ke rakaman skrin sebenar (B-roll). Orang percaya apa yang mereka nampak.
