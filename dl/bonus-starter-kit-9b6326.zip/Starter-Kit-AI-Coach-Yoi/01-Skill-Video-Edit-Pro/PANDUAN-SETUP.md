# Setup Skill Video Edit Pro (sekali sahaja, ±15 minit)

Cara paling mudah: buka Claude Code dalam folder `video-editing`, kemudian taip:

> Setup folder ni untuk skill video-edit-pro: buat venv Python, install imageio-ffmpeg pillow numpy matplotlib faster-whisper, dan buat bin/ffmpeg (Windows: bin/ffmpeg.exe) yang tunjuk ke binary imageio-ffmpeg. Lepas tu test dengan video pendek saya (10-20 saat).

Claude akan buat semua. Kalau nak buat sendiri:

**MacBook (Terminal):**
```
cd video-editing
python3 -m venv venv
venv/bin/pip install imageio-ffmpeg pillow numpy matplotlib faster-whisper
mkdir -p bin && ln -sf "$(venv/bin/python -c 'import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())')" bin/ffmpeg
```

**Windows (PowerShell):**
```
cd video-editing
py -m venv venv
venv\Scripts\pip install imageio-ffmpeg pillow numpy matplotlib faster-whisper
mkdir bin
copy (venv\Scripts\python -c "import imageio_ffmpeg;print(imageio_ffmpeg.get_ffmpeg_exe())") bin\ffmpeg.exe
```
Di Windows, tukar `venv/bin/python` dalam SKILL.md kepada `venv\Scripts\python`.
Nota: zscale (tukar HDR iPhone) mungkin tiada dalam sesetengah binary ffmpeg; kalau ralat, guna arahan SDR biasa dalam langkah 2.

**Pasang skill dalam Claude Code:**
Salin `SKILL.md` ke `~/.claude/skills/video-edit-pro/SKILL.md` (Windows: `C:\Users\<nama>\.claude\skills\video-edit-pro\SKILL.md`).
Lepas tu cukup cakap: *"Edit video ni, buang pause, letak caption 3D"* dan beri lokasi video.

**Font:** caption guna Impact & Arial Black (ada dalam MacBook dan Windows). Kalau tiada, letak fail .ttf dalam folder `video-editing/fonts/`.
Warna brand: tukar `ACC = "#FFD400"` dalam `engine/render.py`.
