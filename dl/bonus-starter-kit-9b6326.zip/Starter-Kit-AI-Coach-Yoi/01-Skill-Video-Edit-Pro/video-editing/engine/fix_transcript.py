"""Replace whisper text with corrected text per segment, keeping timing.
usage: fix_transcript.py transcript.json fixed_text.json out.json"""
import json, sys
segs = json.load(open(sys.argv[1])); texts = json.load(open(sys.argv[2]))
assert len(segs) == len(texts), (len(segs), len(texts))
out = []
for s, txt in zip(segs, texts):
    new = txt.split(); old = s["words"]
    if len(new) == len(old):
        ws = [{"w": n, "s": o["s"], "e": o["e"]} for n, o in zip(new, old)]
    else:
        t0, t1 = old[0]["s"], old[-1]["e"]; tot = sum(len(n) + 2 for n in new); acc = 0; ws = []
        for n in new:
            a = t0 + (t1 - t0) * acc / tot; acc += len(n) + 2
            ws.append({"w": n, "s": a, "e": t0 + (t1 - t0) * acc / tot})
    out.append({"start": s["start"], "end": s["end"], "text": txt, "words": ws})
json.dump(out, open(sys.argv[3], "w"), ensure_ascii=False, indent=1)
