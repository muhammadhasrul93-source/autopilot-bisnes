#!/usr/bin/env python3
"""Cut silent parts (jump cuts) and remap transcript/spec times.
usage: cut_silence.py <src_proj> <dst_proj> [noise_db=-32] [min_sil=0.3] [pad_pre=0.08] [pad_post=0.12] [tail=0.5]
src needs base_sdr.mp4, audio.wav, transcript.json, spec.json. dst gets the same files (cut)."""
import json, os, re, subprocess, sys, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FF = os.path.join(ROOT, "bin", "ffmpeg.exe" if os.name == "nt" else "ffmpeg")
src, dst = sys.argv[1], sys.argv[2]
a = [float(x) for x in sys.argv[3:]] + [None] * 6
noise = a[0] if a[0] is not None else -32
min_sil = a[1] or 0.3; pre = a[2] if a[2] is not None else 0.08
post = a[3] if a[3] is not None else 0.12; tail = a[4] if a[4] is not None else 0.5
os.makedirs(dst, exist_ok=True)
err = subprocess.run([FF, "-hide_banner", "-i", os.path.join(src, "audio.wav"), "-af",
                      f"silencedetect=noise={noise}dB:d={min_sil}", "-f", "null", "-"],
                     capture_output=True, text=True).stderr
dur = float(re.search(r"Duration: (\d+):(\d+):([\d.]+)", err).group(3)) + 60 * int(
    re.search(r"Duration: (\d+):(\d+)", err).group(2))
starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", err)]
ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", err)]
if len(ends) < len(starts): ends.append(dur)
sil = list(zip(starts, ends))
# keep segments = complement of silences shrunk by padding
keep, cur = [], 0.0
for s, e in sil:
    is_end = e >= dur - 0.05
    cut_s = s + (tail if is_end else post)
    cut_e = e - pre if s > 0.01 else e - pre
    if s <= 0.01: cut_s = 0.0
    if cut_e - cut_s > 0.05:
        if cut_s > cur: keep.append((cur, cut_s))
        cur = max(cur, cut_e)
if cur < dur and not (sil and sil[-1][1] >= dur - 0.05 and cur >= sil[-1][0]):
    keep.append((cur, dur))
keep = [(max(0, s), min(dur, e)) for s, e in keep if e - s > 0.05]
merged = []
for s, e in keep:  # merge tiny gaps (jump not worth it)
    if merged and s - merged[-1][1] < 0.25: merged[-1] = (merged[-1][0], e)
    else: merged.append((s, e))
keep = merged
# optional content cuts: <src>/drop.json = [[start, end], ...] (seconds, source timeline) for
# false starts, repeated sentences, fillers and off-topic parts (user 27 Nov: cut anything not important)
dp = os.path.join(src, "drop.json")
if os.path.exists(dp):
    for ds, de in json.load(open(dp)):
        nk = []
        for s, e in keep:
            if de <= s or ds >= e: nk.append((s, e)); continue
            if ds > s: nk.append((s, ds))
            if de < e: nk.append((de, e))
        keep = [(s, e) for s, e in nk if e - s > 0.05]
print("keep:", [(round(s, 2), round(e, 2)) for s, e in keep])
newdur = sum(e - s for s, e in keep); print(f"duration {dur:.2f} -> {newdur:.2f}")

def remap(t):
    acc = 0.0
    for s, e in keep:
        if t < s: return acc
        if t <= e: return acc + (t - s)
        acc += e - s
    return acc

# video/audio cut
fc, n = [], len(keep)
for i, (s, e) in enumerate(keep):
    fc.append(f"[0:v]trim={s}:{e},setpts=PTS-STARTPTS[v{i}]")
    fc.append(f"[0:a]atrim={s}:{e},asetpts=PTS-STARTPTS,afade=t=in:d=0.015,afade=t=out:st={max(0, e - s - 0.02)}:d=0.02[a{i}]")
fc.append("".join(f"[v{i}][a{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=1[v][a]")
subprocess.run([FF, "-v", "error", "-y", "-i", os.path.join(src, "base_sdr.mp4"), "-filter_complex", ";".join(fc),
                "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "14",
                "-c:a", "aac", "-b:a", "192k", os.path.join(dst, "base_sdr.mp4")], check=True)
subprocess.run([FF, "-v", "error", "-y", "-i", os.path.join(dst, "base_sdr.mp4"), "-vn", "-ac", "1", "-ar", "16000",
                os.path.join(dst, "audio.wav")], check=True)
tr = json.load(open(os.path.join(src, "transcript.json")))
for sgm in tr:
    sgm["start"], sgm["end"] = remap(sgm["start"]), remap(sgm["end"])
    for w in sgm["words"]: w["s"], w["e"] = remap(w["s"]), remap(w["e"])
json.dump(tr, open(os.path.join(dst, "transcript.json"), "w"), ensure_ascii=False, indent=1)
sp = json.load(open(os.path.join(src, "spec.json")))
for g in sp.get("graphics", []):
    g["t0"], g["t1"] = remap(g["t0"]), remap(g["t1"])
    g["t1"] = min(g["t1"], newdur)
for z in sp.get("zooms", []): z["t"] = remap(z["t"])
for b in sp.get("broll", []):  # real screen-recording overlays
    b["t0"], b["t1"] = remap(b["t0"]), min(remap(b["t1"]), newdur)
sp["duration"] = newdur
json.dump(sp, open(os.path.join(dst, "spec.json"), "w"), ensure_ascii=False, indent=1)
json.dump(keep, open(os.path.join(dst, "cuts.json"), "w"))
print("done", dst)
