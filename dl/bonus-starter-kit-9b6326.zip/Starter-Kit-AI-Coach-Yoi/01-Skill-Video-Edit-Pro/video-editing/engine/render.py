#!/usr/bin/env python3
"""Pro talking-head editor: 3D captions, motion graphics, animated research charts.

Usage: venv/bin/python engine/render.py <project_dir>
Project dir needs: base_sdr.mp4 (SDR, vertical), transcript.json (from transcribe.py), spec.json.
Output: <project_dir>/final.mp4
"""
import json, math, os, subprocess, sys, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FFMPEG = os.path.join(ROOT, "bin", "ffmpeg.exe" if os.name == "nt" else "ffmpeg")
W, H, FPS = 1080, 1920, 30

def _pick(*names):
    """Cari font pertama yang wujud (MacBook / Windows / fallback)."""
    dirs = ["/System/Library/Fonts/Supplemental", "/Library/Fonts", "C:/Windows/Fonts",
            os.path.expanduser("~/AppData/Local/Microsoft/Windows/Fonts"), os.path.join(ROOT, "fonts")]
    for n in names:
        for d in dirs:
            p = os.path.join(d, n)
            if os.path.exists(p): return p
    return "DejaVuSans-Bold.ttf"
F_IMPACT = _pick("Impact.ttf", "impact.ttf")
F_BLACK = _pick("Arial Black.ttf", "ariblk.ttf", "arialbd.ttf")
F_DIN = _pick("DIN Condensed Bold.ttf", "bahnschrift.ttf", "impact.ttf", "Impact.ttf")
F_DINA = _pick("DIN Alternate Bold.ttf", "bahnschrift.ttf", "arialbd.ttf", "Arial Bold.ttf")
_fc = {}
def font(path, size):
    k = (path, int(size))
    if k not in _fc:
        _fc[k] = ImageFont.truetype(path, int(size))
    return _fc[k]

# ---------------- easing ----------------
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def ease_out(x): x = clamp(x); return 1 - (1 - x) ** 3
def ease_in_out(x): x = clamp(x); return 3 * x * x - 2 * x * x * x
def back_out(x, s=1.7):
    x = clamp(x) - 1
    return x * x * ((s + 1) * x + s) + 1
def env(t, t0, t1, fin=0.35, fout=0.3):
    """0..1 appear progress, and disappear progress"""
    return clamp((t - t0) / fin), clamp((t1 - t) / fout)

def hexc(h, a=255):
    h = h.lstrip("#"); return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

# ---------------- 3D extruded text sprite ----------------
def text3d(text, size, face_top="#FFFFFF", face_bot="#D9D9D9", side="#0A0A0A",
           depth=14, stroke=8, fontpath=F_IMPACT, glow=None, tracking=0):
    f = font(fontpath, size)
    bbox = f.getbbox(text, stroke_width=stroke)
    tw = bbox[2] - bbox[0] + depth + stroke * 2 + 40 + tracking * len(text)
    th = bbox[3] - bbox[1] + depth + stroke * 2 + 40
    img = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
    ox, oy = 20 - bbox[0] + stroke, 20 - bbox[1] + stroke
    # soft drop shadow
    sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).text((ox + depth + 6, oy + depth + 10), text, font=f, fill=(0, 0, 0, 170),
                            stroke_width=stroke, stroke_fill=(0, 0, 0, 170))
    img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(10)))
    if glow:
        g = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(g).text((ox, oy), text, font=f, fill=hexc(glow, 200), stroke_width=stroke + 6,
                               stroke_fill=hexc(glow, 200))
        img.alpha_composite(g.filter(ImageFilter.GaussianBlur(14)))
    d = ImageDraw.Draw(img)
    sc = hexc(side)
    for i in range(depth, 0, -1):  # extrusion
        k = 0.55 + 0.45 * (1 - i / depth)
        col = (int(sc[0] * k), int(sc[1] * k), int(sc[2] * k), 255)
        d.text((ox + i, oy + i), text, font=f, fill=col, stroke_width=stroke, stroke_fill=col)
    d.text((ox, oy), text, font=f, fill=(0, 0, 0, 255), stroke_width=stroke, stroke_fill=(0, 0, 0, 255))
    # gradient face
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).text((ox, oy), text, font=f, fill=255)
    grad = Image.new("RGBA", img.size)
    a, b = hexc(face_top), hexc(face_bot)
    y0, y1 = oy + bbox[1], oy + bbox[3]
    arr = np.zeros((img.size[1], img.size[0], 4), np.uint8)
    ys = np.clip((np.arange(img.size[1]) - y0) / max(1, (y1 - y0)), 0, 1)[:, None]
    for c in range(3):
        arr[:, :, c] = (a[c] * (1 - ys) + b[c] * ys).astype(np.uint8)
    arr[:, :, 3] = 255
    grad = Image.fromarray(arr)
    img.paste(grad, (0, 0), mask)
    # specular highlight band on top third
    hl = Image.new("L", img.size, 0)
    ImageDraw.Draw(hl).rectangle([0, 0, img.size[0], int(y0 + (y1 - y0) * 0.38)], fill=70)
    hl = Image.fromarray((np.array(hl) * (np.array(mask) / 255)).astype(np.uint8))
    img.paste(Image.new("RGBA", img.size, (255, 255, 255, 255)), (0, 0), hl)
    return img

def tilt(img, ang):
    """fake 3D Y-rotation: perspective squash one side"""
    if abs(ang) < 0.01: return img
    w, h = img.size
    k = math.sin(ang) * 0.18
    # coefficients map output->input; shrink the far edge vertically
    src = [(0, 0), (w, 0), (w, h), (0, h)]
    if k > 0: dst = [(0, 0), (w, h * k), (w, h * (1 - k)), (0, h)]
    else: dst = [(0, -h * k), (w, 0), (w, h), (0, h * (1 + k))]
    coeffs = _persp(dst, src)
    return img.transform((w, h), Image.PERSPECTIVE, coeffs, Image.BICUBIC)

def _persp(pa, pb):
    m = []
    for p1, p2 in zip(pa, pb):
        m.append([p1[0], p1[1], 1, 0, 0, 0, -p2[0] * p1[0], -p2[0] * p1[1]])
        m.append([0, 0, 0, p1[0], p1[1], 1, -p2[1] * p1[0], -p2[1] * p1[1]])
    A = np.array(m, dtype=float); B = np.array(pb, dtype=float).reshape(8)
    return np.linalg.solve(A, B).tolist()

def paste_center(canvas, spr, cx, cy, scale=1.0, alpha=1.0, rot=0):
    if scale <= 0.01 or alpha <= 0.01: return
    s = spr
    if abs(scale - 1) > 0.005:
        s = s.resize((max(1, int(s.width * scale)), max(1, int(s.height * scale))), Image.BICUBIC)
    if rot: s = s.rotate(rot, Image.BICUBIC, expand=True)
    if alpha < 0.999:
        a = s.getchannel("A").point(lambda v: int(v * alpha)); s = s.copy(); s.putalpha(a)
    canvas.alpha_composite(s, (int(cx - s.width / 2), int(cy - s.height / 2)))

# ---------------- glass card ----------------
def card(w, h, r=36, fill=(12, 14, 20, 210), border=(255, 255, 255, 60), accent=None):
    img = Image.new("RGBA", (w + 60, h + 60), (0, 0, 0, 0))
    sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([30, 40, 30 + w, 40 + h], r, fill=(0, 0, 0, 150))
    img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(18)))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([30, 30, 30 + w, 30 + h], r, fill=fill, outline=border, width=3)
    if accent:
        d.rounded_rectangle([30, 30, 30 + w, 30 + 12], 6, fill=hexc(accent))
    return img

# ---------------- graphics ----------------
ACC = "#FFD400"  # warna brand (tukar ikut brand awak)

def g_bar_chart(t, ev):
    """animated research bar chart"""
    t0, t1 = ev["t0"], ev["t1"]
    pin, pout = env(t, t0, t1, 0.45, 0.35)
    if pin <= 0 or pout <= 0: return None
    cw, ch = 940, 760
    img = card(cw, ch, accent=ACC)
    d = ImageDraw.Draw(img)
    d.text((70, 72), ev.get("kicker", "KAJIAN").upper(), font=font(F_DINA, 34), fill=hexc(ACC))
    d.text((70, 112), ev["title"], font=font(F_BLACK, 46), fill=(255, 255, 255, 255))
    bars = ev["bars"]; mx = max(b["v"] for b in bars) * 1.12
    n = len(bars); top, bot = 250, ch - 60
    bw = int((cw - 120) / n * 0.62); gap = (cw - 120) / n
    for i, b in enumerate(bars):
        p = ease_out((t - t0 - 0.35 - i * 0.18) / 0.9)
        x = 60 + 30 + gap * i + (gap - bw) / 2
        hh = (bot - top - 70) * b["v"] / mx * p
        col = hexc(b.get("c", ACC if b.get("hi") else "#5B6170"))
        d.rounded_rectangle([x, 30 + bot - hh, x + bw, 30 + bot], 14, fill=col)
        val = b["v"] * p
        lab = (b.get("fmt", "{:.0f}")).format(val) + b.get("unit", "")
        f = font(F_DIN, 64)
        tw = d.textlength(lab, font=f)
        d.text((x + bw / 2 - tw / 2, 30 + bot - hh - 72), lab, font=f, fill=(255, 255, 255, int(255 * clamp(p * 2))))
        f2 = font(F_DINA, 30)
        for j, line in enumerate(b["l"].split("\n")):
            tw = d.textlength(line, font=f2)
            d.text((x + bw / 2 - tw / 2, 30 + bot + 12 + j * 34), line, font=f2, fill=(220, 220, 225, 255))
    if ev.get("src"):
        d.text((70, 30 + ch + 0), "", font=font(F_DINA, 1))
    out = Image.new("RGBA", (img.width, img.height + 70), (0, 0, 0, 0))
    out.alpha_composite(img)
    if ev.get("src"):
        ImageDraw.Draw(out).text((40, img.height + 5), "Sumber: " + ev["src"], font=font(F_DINA, 28),
                                 fill=(255, 255, 255, 210))
    a = min(pin, pout)
    sc = 0.86 + 0.14 * back_out(pin) if pout >= 1 else 0.96 + 0.04 * pout
    return out, sc, ease_out(a), (1 - ease_out(pin)) * 80

def g_line_chart(t, ev):
    t0, t1 = ev["t0"], ev["t1"]
    pin, pout = env(t, t0, t1, 0.45, 0.35)
    if pin <= 0 or pout <= 0: return None
    cw, ch = 940, 720
    img = card(cw, ch, accent=ACC); d = ImageDraw.Draw(img)
    d.text((70, 72), ev.get("kicker", "KAJIAN").upper(), font=font(F_DINA, 34), fill=hexc(ACC))
    d.text((70, 112), ev["title"], font=font(F_BLACK, 46), fill=(255, 255, 255, 255))
    x0, x1, y0, y1 = 110, cw - 40, 250, ch - 40
    for k in range(5):
        yy = y0 + (y1 - y0) * k / 4
        d.line([x0, yy, x1, yy], fill=(255, 255, 255, 35), width=2)
    series = ev["series"]
    allv = [v for s in series for v in s["v"]]
    lo, hi = min(allv + [0]), max(allv) * 1.1
    prog = ease_in_out((t - t0 - 0.3) / 1.6)
    for s in series:
        vs = s["v"]; n = len(vs)
        pts = [(x0 + (x1 - x0) * i / (n - 1), y1 - (y1 - y0) * (v - lo) / (hi - lo)) for i, v in enumerate(vs)]
        upto = prog * (n - 1); seg = int(upto)
        draw = pts[:seg + 1]
        if seg < n - 1:
            fr = upto - seg; a, b = pts[seg], pts[seg + 1]
            draw.append((a[0] + (b[0] - a[0]) * fr, a[1] + (b[1] - a[1]) * fr))
        col = hexc(s.get("c", ACC))
        if len(draw) > 1:
            d.line(draw, fill=col, width=10, joint="curve")
            ex, ey = draw[-1]
            d.ellipse([ex - 14, ey - 14, ex + 14, ey + 14], fill=col)
            lab = s["name"]
            d.text((min(ex + 18, x1 - 200), ey - 50), lab, font=font(F_DINA, 32), fill=col)
    for i, xl in enumerate(ev.get("xl", [])):
        xx = x0 + (x1 - x0) * i / (len(ev["xl"]) - 1)
        tw = d.textlength(xl, font=font(F_DINA, 28))
        d.text((xx - tw / 2, y1 + 8), xl, font=font(F_DINA, 28), fill=(200, 200, 205, 255))
    out = Image.new("RGBA", (img.width, img.height + 70), (0, 0, 0, 0)); out.alpha_composite(img)
    if ev.get("src"):
        ImageDraw.Draw(out).text((40, img.height + 5), "Sumber: " + ev["src"], font=font(F_DINA, 28), fill=(255, 255, 255, 210))
    sc = 0.86 + 0.14 * back_out(pin) if pout >= 1 else 0.96 + 0.04 * pout
    return out, sc, ease_out(min(pin, pout)), (1 - ease_out(pin)) * 80

def g_stat(t, ev):
    """big counting number + label + ring"""
    t0, t1 = ev["t0"], ev["t1"]
    pin, pout = env(t, t0, t1, 0.4, 0.3)
    if pin <= 0 or pout <= 0: return None
    cw, ch = 900, 470
    img = card(cw, ch, accent=ACC); d = ImageDraw.Draw(img)
    p = ease_out((t - t0 - 0.2) / 1.1)
    cx, cy, R = 30 + 190, 30 + ch / 2 + 10, 140
    d.ellipse([cx - R, cy - R, cx + R, cy + R], outline=(255, 255, 255, 40), width=26)
    frac = ev.get("ring", 1.0) * p
    if frac > 0:
        d.arc([cx - R, cy - R, cx + R, cy + R], -90, -90 + 360 * frac, fill=hexc(ACC), width=26)
    val = ev["v"] * p
    s = ev.get("fmt", "{:.0f}").format(val) + ev.get("unit", "")
    f = font(F_DIN, 120); tw = d.textlength(s, font=f)
    d.text((cx - tw / 2, cy - 66), s, font=f, fill=(255, 255, 255, 255))
    d.text((430, 90), ev.get("kicker", "FAKTA").upper(), font=font(F_DINA, 34), fill=hexc(ACC))
    y = 140
    for line in ev["label"].split("\n"):
        d.text((430, y), line, font=font(F_BLACK, 44), fill=(255, 255, 255, 255)); y += 58
    if ev.get("src"):
        d.text((430, ch - 40), "Sumber: " + ev["src"], font=font(F_DINA, 26), fill=(200, 200, 205, 255))
    sc = 0.86 + 0.14 * back_out(pin) if pout >= 1 else 0.96 + 0.04 * pout
    return img, sc, ease_out(min(pin, pout)), (1 - ease_out(pin)) * 80

def g_checklist(t, ev):
    t0, t1 = ev["t0"], ev["t1"]
    pin, pout = env(t, t0, t1, 0.4, 0.3)
    if pin <= 0 or pout <= 0: return None
    items = ev["items"]; cw = 920; ch = 170 + 100 * len(items)
    img = card(cw, ch, accent=ACC); d = ImageDraw.Draw(img)
    d.text((70, 72), ev["title"], font=font(F_BLACK, 50), fill=(255, 255, 255, 255))
    for i, it in enumerate(items):
        p = ease_out((t - t0 - 0.3 - i * ev.get("stagger", 0.45)) / 0.4)
        if p <= 0: continue
        y = 170 + i * 100; x = 70 - (1 - p) * 60
        ok = it.get("ok", True)
        col = hexc("#2BD96B" if ok else "#FF4D4D")
        d.rounded_rectangle([x, y, x + 64, y + 64], 16, fill=col)
        mark = "✓" if ok else "✕"
        d.text((x + 13, y + 2), mark, font=font(_pick("Arial Unicode.ttf", "seguisym.ttf", "Arial Black.ttf", "ariblk.ttf"), 50),
               fill=(0, 0, 0, int(255 * p)))
        d.text((x + 90, y + 4), it["t"], font=font(F_BLACK, 44), fill=(255, 255, 255, int(255 * p)))
    sc = 0.86 + 0.14 * back_out(pin) if pout >= 1 else 0.96 + 0.04 * pout
    return img, sc, ease_out(min(pin, pout)), (1 - ease_out(pin)) * 80

def g_title(t, ev):
    """hook title: big 3D words slam in"""
    t0, t1 = ev["t0"], ev["t1"]
    pin, pout = env(t, t0, t1, 0.3, 0.25)
    if pin <= 0 or pout <= 0: return None
    if "_spr" not in ev:
        ev["_spr"] = [text3d(l["t"], l.get("size", 120), face_top=l.get("c", "#FFFFFF"),
                             face_bot=l.get("c2", "#CFCFCF"), depth=18, glow=l.get("glow"))
                      for l in ev["lines"]]
    sprs = ev["_spr"]
    hh = sum(s.height for s in sprs) - 30 * (len(sprs) - 1)
    out = Image.new("RGBA", (W, hh + 40), (0, 0, 0, 0)); y = 20
    for i, s in enumerate(sprs):
        p = clamp((t - t0 - i * 0.18) / 0.35)
        sc = 1.6 - 0.6 * back_out(p) if p < 1 else 1.0
        paste_center(out, tilt(s, 0.12 * math.sin(t * 1.3 + i)), W / 2, y + s.height / 2, sc, ease_out(p) * pout)
        y += s.height - 30
    return out, 1.0, 1.0, 0

def g_cta(t, ev):
    t0, t1 = ev["t0"], ev["t1"]
    pin, pout = env(t, t0, t1, 0.4, 0.3)
    if pin <= 0 or pout <= 0: return None
    cw, ch = 900, 300
    img = card(cw, ch, fill=(255, 212, 0, 240), border=(255, 255, 255, 120)); d = ImageDraw.Draw(img)
    pulse = 1 + 0.03 * math.sin((t - t0) * 7)
    d.text((80, 80), ev["title"], font=font(F_BLACK, 62), fill=(10, 10, 10, 255))
    d.text((80, 170), ev.get("sub", ""), font=font(F_BLACK, 42), fill=(40, 40, 40, 255))
    # arrow
    ax = 30 + cw - 120 + 12 * math.sin((t - t0) * 6)
    d.polygon([(ax, 130), (ax + 60, 180), (ax, 230)], fill=(10, 10, 10, 255))
    sc = (0.86 + 0.14 * back_out(pin)) * pulse
    return img, sc, ease_out(min(pin, pout)), (1 - ease_out(pin)) * 120

# ---------------- WIDE top-zone cards (fit the empty space above the head) ----------------
CW = 1000  # card width

def _wrap_out(img, ev):
    out = Image.new("RGBA", (img.width, img.height + 44), (0, 0, 0, 0)); out.alpha_composite(img)
    if ev.get("src"):
        ImageDraw.Draw(out).text((44, img.height - 8), "Sumber: " + ev["src"], font=font(F_DINA, 26), fill=(255, 255, 255, 225))
    return out

def _anim(t, ev, fin=0.45, fout=0.35):
    pin, pout = env(t, ev["t0"], ev["t1"], fin, fout)
    return pin, pout

def _ret(img, pin, pout):
    sc = 0.86 + 0.14 * back_out(pin) if pout >= 1 else 0.96 + 0.04 * pout
    return img, sc, ease_out(min(pin, pout)), -(1 - ease_out(pin)) * 70

def _head(d, ev, y=60):
    d.text((70, y), ev.get("kicker", "KAJIAN").upper(), font=font(F_DINA, 30), fill=hexc(ACC))
    d.text((70, y + 36), ev["title"], font=font(F_BLACK, 42), fill=(255, 255, 255, 255))

def w_bar(t, ev):
    pin, pout = _anim(t, ev)
    if pin <= 0 or pout <= 0: return None
    bars = ev["bars"]; ch = 160 + 78 * len(bars)
    img = card(CW, ch, accent=ACC); d = ImageDraw.Draw(img); _head(d, ev)
    mx = max(b["v"] for b in bars); x0, x1 = 370, CW - 150
    for i, b in enumerate(bars):
        p = ease_out((t - ev["t0"] - 0.35 - i * 0.22) / 0.9)
        y = 170 + i * 78
        lab = b["l"].replace("\n", " ")
        d.text((70, y + 6), lab, font=font(F_DINA, 32), fill=(230, 230, 235, 255))
        d.rounded_rectangle([x0, y, x1, y + 50], 12, fill=(255, 255, 255, 25))
        w = (x1 - x0) * b["v"] / mx * p
        if w > 6:
            d.rounded_rectangle([x0, y, x0 + w, y + 50], 12, fill=hexc(b.get("c", ACC if b.get("hi") else "#7C8495")))
        val = (b.get("fmt", "{:.0f}")).format(b["v"] * p) + b.get("unit", "")
        d.text((x0 + w + 14, y - 4), val, font=font(F_DIN, 56), fill=(255, 255, 255, int(255 * clamp(p * 2))))
    return _ret(_wrap_out(img, ev), pin, pout)

def w_line(t, ev):
    pin, pout = _anim(t, ev)
    if pin <= 0 or pout <= 0: return None
    ch = 420; img = card(CW, ch, accent=ACC); d = ImageDraw.Draw(img); _head(d, ev)
    x0, x1, y0, y1 = 110, CW - 60, 175, ch - 25
    for k in range(4):
        yy = y0 + (y1 - y0) * k / 3; d.line([x0, yy, x1, yy], fill=(255, 255, 255, 35), width=2)
    prog = ease_in_out((t - ev["t0"] - 0.3) / 1.6)
    for s in ev["series"]:
        vs = s["v"]; n = len(vs); lo, hi = 0, max(vs) * 1.08
        pts = [(x0 + (x1 - x0) * i / (n - 1), y1 - (y1 - y0) * (v - lo) / (hi - lo)) for i, v in enumerate(vs)]
        upto = prog * (n - 1); seg = int(upto); dr = pts[:seg + 1]
        if seg < n - 1:
            fr = upto - seg; a, b = pts[seg], pts[seg + 1]; dr.append((a[0] + (b[0] - a[0]) * fr, a[1] + (b[1] - a[1]) * fr))
        col = hexc(s.get("c", ACC))
        if len(dr) > 1:
            poly = dr + [(dr[-1][0], y1), (dr[0][0], y1)]
            d.polygon(poly, fill=col[:3] + (45,))
            d.line(dr, fill=col, width=9, joint="curve")
            ex, ey = dr[-1]; d.ellipse([ex - 13, ey - 13, ex + 13, ey + 13], fill=col)
            tw = d.textlength(s["name"], font=font(F_DIN, 50))
            d.text((min(ex - tw / 2, x1 - tw), ey - 66), s["name"], font=font(F_DIN, 50), fill=col)
        for i, xl in enumerate(ev.get("xl", [])):
            xx = x0 + (x1 - x0) * i / (len(ev["xl"]) - 1); tw = d.textlength(xl, font=font(F_DINA, 26))
            d.text((min(xx - tw / 2, x1 - tw), y1 - 34), xl, font=font(F_DINA, 26), fill=(210, 210, 215, 255))
    return _ret(_wrap_out(img, ev), pin, pout)

def w_stat(t, ev):
    pin, pout = _anim(t, ev, 0.4, 0.3)
    if pin <= 0 or pout <= 0: return None
    ch = 360; img = card(CW, ch, accent=ACC); d = ImageDraw.Draw(img)
    p = ease_out((t - ev["t0"] - 0.2) / 1.1)
    cx, cy, R = 30 + 175, 30 + ch / 2, 125
    d.ellipse([cx - R, cy - R, cx + R, cy + R], outline=(255, 255, 255, 40), width=24)
    if ev.get("ring", 1) * p > 0: d.arc([cx - R, cy - R, cx + R, cy + R], -90, -90 + 360 * ev.get("ring", 1) * p, fill=hexc(ACC), width=24)
    s = ev.get("fmt", "{:.0f}").format(ev["v"] * p) + ev.get("unit", "")
    f = font(F_DIN, 104); tw = d.textlength(s, font=f); d.text((cx - tw / 2, cy - 58), s, font=f, fill=(255, 255, 255, 255))
    d.text((400, 70), ev.get("kicker", "FAKTA").upper(), font=font(F_DINA, 30), fill=hexc(ACC)); y = 112
    for line in ev["label"].split("\n"):
        d.text((400, y), line, font=font(F_BLACK, 44), fill=(255, 255, 255, 255)); y += 56
    return _ret(_wrap_out(img, ev), pin, pout)

def w_check(t, ev):
    pin, pout = _anim(t, ev, 0.4, 0.3)
    if pin <= 0 or pout <= 0: return None
    items = ev["items"]; ch = 130 + 78 * len(items)
    img = card(CW, ch, accent=ACC); d = ImageDraw.Draw(img)
    d.text((70, 64), ev["title"], font=font(F_BLACK, 46), fill=(255, 255, 255, 255))
    for i, it in enumerate(items):
        p = ease_out((t - ev["t0"] - 0.3 - i * ev.get("stagger", 0.45)) / 0.4)
        if p <= 0: continue
        y = 140 + i * 78; x = 70 - (1 - p) * 60
        d.rounded_rectangle([x, y, x + 58, y + 58], 14, fill=hexc("#2BD96B"))
        d.line([(x + 14, y + 30), (x + 25, y + 42), (x + 45, y + 16)], fill=(0, 0, 0, int(255 * p)), width=8)
        d.text((x + 82, y + 2), it["t"], font=font(F_BLACK, 42), fill=(255, 255, 255, int(255 * p)))
    return _ret(img, pin, pout)

def w_cta(t, ev):
    pin, pout = _anim(t, ev, 0.4, 0.3)
    if pin <= 0 or pout <= 0: return None
    ch = 260; img = card(CW, ch, fill=(255, 212, 0, 240), border=(255, 255, 255, 120)); d = ImageDraw.Draw(img)
    d.text((80, 80), ev["title"], font=font(F_BLACK, 64), fill=(10, 10, 10, 255))
    d.text((80, 168), ev.get("sub", ""), font=font(F_BLACK, 40), fill=(40, 40, 40, 255))
    ax = 30 + CW - 120 + 12 * math.sin((t - ev["t0"]) * 6)
    d.polygon([(ax, 110), (ax + 60, 160), (ax, 210)], fill=(10, 10, 10, 255))
    img, sc, a, dy = _ret(img, pin, pout)
    return img, sc * (1 + 0.025 * math.sin((t - ev["t0"]) * 7)), a, dy

def w_header(t, ev):
    """persistent topic header shown in the top zone whenever no card is on screen"""
    if "_spr" not in ev:
        ev["_spr"] = [text3d(l["t"], l.get("size", 84), face_top=l.get("c", "#FFFFFF"), face_bot=l.get("c2", "#D0D0D0"),
                             depth=12, glow=l.get("glow")) for l in ev["lines"]]
    a = ev.get("_alpha", 1.0)
    if a <= 0.01: return None
    sprs = ev["_spr"]; hh = sum(s.height for s in sprs) - 34 * (len(sprs) - 1) + 60
    out = Image.new("RGBA", (W, hh), (0, 0, 0, 0)); y = 0
    for i, s in enumerate(sprs):
        paste_center(out, tilt(s, 0.10 * math.sin(t * 1.1 + i)), W / 2, y + s.height / 2, 1 + 0.015 * math.sin(t * 2 + i))
        y += s.height - 34
    if ev.get("sub"):
        d = ImageDraw.Draw(out); f = font(F_DINA, 34); tw = d.textlength(ev["sub"], font=f)
        d.rounded_rectangle([W / 2 - tw / 2 - 22, y + 6, W / 2 + tw / 2 + 22, y + 56], 25, fill=(0, 0, 0, 150))
        d.text((W / 2 - tw / 2, y + 12), ev["sub"], font=f, fill=hexc(ACC))
    return out, 1.0, a, 0

GFX = {"bar": w_bar, "line": w_line, "stat": w_stat, "check": w_check,
       "title": g_title, "cta": w_cta, "header": w_header,
       "bar_tall": g_bar_chart, "line_tall": g_line_chart, "stat_tall": g_stat, "check_tall": g_checklist, "cta_tall": g_cta}

# ---------------- captions ----------------
def build_chunks(words, maxw=3, maxgap=0.45, maxchars=16):
    chunks, cur = [], []
    for w in words:
        if cur and (len(cur) >= maxw or w["s"] - cur[-1]["e"] > maxgap
                    or sum(len(x["w"]) + 1 for x in cur) + len(w["w"]) > maxchars
                    or cur[-1]["w"].endswith((".", ",", "?", "!"))):
            chunks.append(cur); cur = []
        cur.append(w)
    if cur: chunks.append(cur)
    out = []
    for i, c in enumerate(chunks):
        end = c[-1]["e"] + 0.15
        if i + 1 < len(chunks): end = min(end, chunks[i + 1][0]["s"])
        out.append({"s": c[0]["s"], "e": max(end, c[0]["s"] + 0.3), "words": c})
    return out

def clean(w): return w.strip().strip(".,?!").upper()

class Captions:
    def __init__(self, chunks, keywords, y):
        self.chunks, self.kw, self.y = chunks, set(k.upper() for k in keywords), y
        self.cache = {}
        self.hide_y = 1770
    def sprite(self, ci, active):
        k = (ci, active)
        if k in self.cache: return self.cache[k]
        ch = self.chunks[ci]; parts = []
        for wi, w in enumerate(ch["words"]):
            word = clean(w["w"])
            hot = word in self.kw
            if wi == active or hot:
                spr = text3d(word, 112 if hot else 104, face_top="#FFF27A" if hot else "#FFE600",
                             face_bot="#FFB300", side="#3A2600", depth=14, glow="#FFB300" if hot else None)
            else:
                spr = text3d(word, 100, depth=12)
            parts.append(spr)
        gap = -34
        tw = sum(p.width for p in parts) + gap * (len(parts) - 1)
        if tw > W - 40:  # shrink to fit
            sc = (W - 40) / tw
            parts = [p.resize((int(p.width * sc), int(p.height * sc)), Image.LANCZOS) for p in parts]
            tw = sum(p.width for p in parts) + gap * (len(parts) - 1)
        hh = max(p.height for p in parts)
        img = Image.new("RGBA", (tw, hh), (0, 0, 0, 0)); x = 0
        for p in parts:
            img.alpha_composite(p, (x, (hh - p.height) // 2)); x += p.width + gap
        self.cache[k] = img
        return img
    def draw(self, canvas, t, hide=False):
        for ci, ch in enumerate(self.chunks):
            if ch["s"] <= t < ch["e"]:
                active = 0
                for wi, w in enumerate(ch["words"]):
                    if t >= w["s"] - 0.03: active = wi
                spr = self.sprite(ci, active)
                p = clamp((t - ch["s"]) / 0.16)
                sc = 0.7 + 0.3 * back_out(p, 2.5)
                ang = 0.25 * math.sin(ci * 1.7)
                y = self.y + (1 - ease_out(p)) * 40
                if hide: y = self.hide_y
                paste_center(canvas, tilt(spr, ang * (1 - p * 0.5)), W / 2, y, sc, ease_out(p) * 1.0,
                             rot=1.5 * math.sin(ci * 2.3))
                return

# ---------------- SFX ----------------
def sfx_track(events, dur, sr=48000):
    n = int(dur * sr) + sr; out = np.zeros(n, np.float32); rng = np.random.default_rng(3)
    for kind, t in events:
        i = int(t * sr)
        if kind == "whoosh":
            L = int(0.45 * sr); noise = rng.standard_normal(L).astype(np.float32)
            e = np.sin(np.linspace(0, math.pi, L)) ** 2
            # sweep lowpass via cumulative smoothing
            k = np.linspace(0.02, 0.35, L); y = np.zeros(L, np.float32); acc = 0.0
            for j in range(L): acc += k[j] * (noise[j] - acc); y[j] = acc
            s = y * e * 0.55
        elif kind == "pop":
            L = int(0.12 * sr); tt = np.arange(L) / sr
            s = np.sin(2 * math.pi * (900 - 3000 * tt) * tt) * np.exp(-tt * 40) * 0.35
        elif kind == "hit":
            L = int(0.6 * sr); tt = np.arange(L) / sr
            s = (np.sin(2 * math.pi * 55 * tt) * np.exp(-tt * 7) * 0.8 +
                 rng.standard_normal(L) * np.exp(-tt * 30) * 0.25)
        else: continue
        j = min(n, i + len(s)); out[i:j] += s[: j - i].astype(np.float32)
    return np.clip(out, -1, 1)

def write_wav(path, x, sr=48000):
    import wave
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((x * 32767).astype(np.int16).tobytes())

# ---------------- main ----------------
def main(proj, preview=None):
    spec = json.load(open(os.path.join(proj, "spec.json")))
    words = [w for s in json.load(open(os.path.join(proj, "transcript.json"))) for w in s["words"]]
    for fx in spec.get("word_fix", []):  # spelling fixes
        for w in words:
            if clean(w["w"]) == fx[0].upper(): w["w"] = fx[1]
    chunks = build_chunks(words)
    caps = Captions(chunks, spec.get("keywords", []), spec.get("caption_y", 1380))
    gfx = spec["graphics"]; zooms = spec.get("zooms", [])
    dur = spec.get("duration") or float(subprocess.run(
        [FFMPEG, "-i", os.path.join(proj, "base_sdr.mp4")], capture_output=True, text=True
    ).stderr.split("Duration: ")[1].split(",")[0].split(":")[-1])
    # SFX
    ev = []
    for g in gfx:
        if g["type"] != "header": ev.append(("whoosh", max(0, g["t0"] - 0.15)))
    for z in zooms: ev.append(("hit" if z.get("hit") else "pop", z["t"]))
    for b in spec.get("broll", []): ev.append(("whoosh", max(0, b["t0"] - 0.12)))
    write_wav(os.path.join(proj, "sfx.wav"), sfx_track(ev, dur))
    t_start, t_end = (preview or (0, dur))
    nfr = int((t_end - t_start) * FPS)
    dec = subprocess.Popen([FFMPEG, "-v", "error", "-ss", str(t_start), "-t", str(t_end - t_start),
                            "-i", os.path.join(proj, "base_sdr.mp4"), "-vf", f"scale={W}:{H},fps={FPS}",
                            "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
    outname = "preview.mp4" if preview else "final.mp4"
    enc = subprocess.Popen([FFMPEG, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}",
                            "-r", str(FPS), "-i", "-", "-ss", str(t_start), "-t", str(t_end - t_start),
                            "-i", os.path.join(proj, "base_sdr.mp4"),
                            "-ss", str(t_start), "-t", str(t_end - t_start), "-i", os.path.join(proj, "sfx.wav"),
                            "-filter_complex", "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11[v];[2:a]volume=0.55[s];[v][s]amix=inputs=2:duration=first:normalize=0[a]",
                            "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-preset", "medium", "-crf", "18",
                            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
                            os.path.join(proj, outname)], stdin=subprocess.PIPE)
    # vignette mask
    yy, xx = np.mgrid[0:H, 0:W]
    vig = 1 - 0.35 * np.clip(((xx - W / 2) / (W / 1.1)) ** 2 + ((yy - H / 2) / (H / 1.1)) ** 2, 0, 1)
    vig = vig[:, :, None].astype(np.float32)
    # B-roll (real screen proof) overlays: full-frame cutaway + face bubble
    brolls = spec.get("broll", [])
    for b in brolls: b["_dec"] = None
    PIP = 250
    pmask = Image.new("L", (PIP, PIP), 0); ImageDraw.Draw(pmask).ellipse([0, 0, PIP - 1, PIP - 1], fill=255)
    def broll_frame(t):
        for b in brolls:
            if b["t0"] - 0.01 <= t < b["t1"]:
                if b["_dec"] is None:
                    b["_dec"] = subprocess.Popen([FFMPEG, "-v", "error", "-ss", str(max(0, t - b["t0"])), "-i",
                                                  os.path.join(proj, "broll", b["clip"] + ".mp4"), "-f", "rawvideo",
                                                  "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
                    b["_last"] = None
                raw = b["_dec"].stdout.read(W * H * 3)
                if len(raw) == W * H * 3: b["_last"] = np.frombuffer(raw, np.uint8).reshape(H, W, 3)
                return b, b["_last"]
            if t >= b["t1"] and b["_dec"] is not None:
                b["_dec"].kill(); b["_dec"] = None
        return None, None
    # dim layer for graphics focus
    for fi in range(nfr):
        t = t_start + fi / FPS
        raw = dec.stdout.read(W * H * 3)
        if len(raw) < W * H * 3: break
        frame = np.frombuffer(raw, np.uint8).reshape(H, W, 3)
        # punch-in zooms
        z = 1.0
        for zz in zooms:
            if zz["t"] <= t < zz["t"] + zz.get("d", 1.2):
                p = (t - zz["t"]) / zz.get("d", 1.2)
                z = max(z, 1 + (zz.get("z", 1.12) - 1) * (back_out(clamp(p * 4)) if p < 0.75 else ease_in_out((1 - p) * 4)))
        base = Image.fromarray(frame)
        if z > 1.001:
            cw_, ch_ = int(W / z), int(H / z); cy = int(zz.get("cy", 0.42) * H)
            y0 = clamp(cy - ch_ / 2, 0, H - ch_)
            base = base.crop((int((W - cw_) / 2), int(y0), int((W - cw_) / 2) + cw_, int(y0) + ch_)).resize((W, H), Image.BICUBIC)
        arr = np.asarray(base).astype(np.float32) * vig
        bb, bf = broll_frame(t)
        in_broll = bf is not None
        if in_broll:
            k = clamp(min((t - bb["t0"]) / 0.22, (bb["t1"] - t) / 0.22))
            face = Image.fromarray(frame).crop((540 - 380, 760 - 380, 540 + 380, 760 + 380)).resize((PIP, PIP), Image.LANCZOS)
            comp = Image.fromarray(bf).convert("RGBA")
            ring = Image.new("RGBA", (PIP + 16, PIP + 16), (0, 0, 0, 0))
            ImageDraw.Draw(ring).ellipse([0, 0, PIP + 15, PIP + 15], fill=hexc(ACC))
            comp.alpha_composite(ring, (W - PIP - 46, 92))
            comp.paste(face, (W - PIP - 38, 100), pmask)
            arr = arr * (1 - k) + np.asarray(comp.convert("RGB")).astype(np.float32) * k
        # darken when a card is on
        active = [g for g in gfx if g["type"] not in ("title", "header") and g["t0"] <= t < g["t1"]]
        if active:
            g = active[0]; pin, pout = env(t, g["t0"], g["t1"], 0.4, 0.3)
            arr *= 1 - spec.get("dim", 0.12) * ease_out(min(pin, pout))
        canvas = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).convert("RGBA")
        ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        busy = 0.0
        for g in gfx:
            if g["type"] == "header": continue
            b = clamp(min((t - (g["t0"] - 0.35)) / 0.35, ((g["t1"] + 0.35) - t) / 0.35))
            busy = max(busy, b)
        for g in gfx:
            if g["type"] == "header":
                g["_alpha"] = 1 - busy if g.get("t0", 0) <= t < g.get("t1", 1e9) else 0
            r = GFX[g["type"]](t, g)
            if not r: continue
            img, sc, a, dy = r
            paste_center(ov, img, W / 2, g.get("y", 1170) + dy, sc * (spec.get("gfx_scale", 1.0) if g["type"] not in ("title", "header") else 1.0), a)
        hide = bool(active)
        if not any(g["type"] == "title" and g["t0"] <= t < g["t1"] for g in gfx):
            caps.hide_y = spec.get('caption_hide_y', 1770)
            caps.y = 1650 if in_broll else spec.get("caption_y", 1380)
            if in_broll: caps.hide_y = 1650
            caps.draw(ov, t, hide=hide)
        # progress bar
        d = ImageDraw.Draw(ov)
        d.rectangle([0, H - 14, W, H], fill=(255, 255, 255, 50))
        d.rectangle([0, H - 14, int(W * t / dur), H], fill=hexc(ACC))
        # brand tag
        if spec.get("handle") and not in_broll:
            d.text((40, 70), spec["handle"], font=font(F_DINA, 40), fill=(255, 255, 255, 200))
        canvas.alpha_composite(ov)
        enc.stdin.write(canvas.convert("RGB").tobytes())
        if fi % 60 == 0: print(f"frame {fi}/{nfr}", flush=True)
    enc.stdin.close(); enc.wait(); dec.stdout.close(); dec.kill(); dec.wait()
    print("OUT", os.path.join(proj, outname))

if __name__ == "__main__":
    pv = None
    if len(sys.argv) > 3: pv = (float(sys.argv[2]), float(sys.argv[3]))
    main(sys.argv[1], pv)
