/**
 * ============================================================
 * AUTO-EMAIL PRODUK SELEPAS BAYARAN STRIPE (Google Apps Script)
 * ============================================================
 *
 * APA SKRIP INI BUAT:
 *   Setiap 5 minit, skrip mencari email notifikasi Stripe dalam Gmail anda
 *   yang bertajuk seperti:
 *       "Payment of RM39.00 from pembeli@contoh.com for [NAMA_BISNES_STRIPE]"
 *   Kemudian ia:
 *     1. Semak email itu BENAR-BENAR dari Stripe (DKIM pass), bukan email palsu.
 *     2. Baca jumlah bayaran (contoh 39.00) dan padankan dengan pakej dalam CONFIG.PAKEJ.
 *     3. Hantar email cantik kepada pembeli dengan pautan muat turun.
 *     4. Letak label pada thread Gmail itu supaya pembeli tidak menerima email 2 kali.
 *   Jika jumlah tidak dikenali atau email pembeli tiada, anda (pemilik) akan
 *   menerima email "Semak manual".
 *
 * SYARAT DI STRIPE:
 *   Stripe Dashboard > Settings (ikon gear) > Personal details / Communication preferences
 *   > hidupkan "Successful payments" supaya Stripe email anda setiap kali ada bayaran.
 *   Email Stripe itu MESTI masuk ke akaun Gmail yang sama yang menjalankan skrip ini.
 *
 * CARA PASANG (ringkas, langkah penuh dalam PANDUAN.pdf):
 *   1. script.google.com > New project > padam kod contoh > tampal SEMUA kod ini.
 *   2. Isi bahagian CONFIG di bawah (semua [KURUNGAN]).
 *   3. Pilih fungsi "testEmailKeSaya" > Run > benarkan akses (Allow). Semak inbox anda.
 *   4. Pilih fungsi "setup" > Run. Trigger 5 minit akan aktif. Siap.
 *
 * KUOTA: akaun Gmail biasa boleh hantar ±100 email sehari melalui Apps Script.
 *        Google Workspace ±1,500 sehari.
 */

// ============================================================
// CONFIG: tukar semua nilai dalam [KURUNGAN] kepada maklumat anda
// ============================================================
var CONFIG = {
  // Nama yang dipaparkan sebagai pengirim email.
  SENDER_NAME: '[NAMA_ANDA_ATAU_BISNES]',

  // Email anda sendiri: untuk notifikasi "semak manual" dan email ujian.
  OWNER_EMAIL: '[EMAIL_ANDA]',

  // Nama bisnes TEPAT seperti dalam tajuk email Stripe, selepas perkataan "for".
  // Contoh tajuk: "Payment of RM39.00 from ali@contoh.com for Kedai Ali"  ->  'Kedai Ali'
  // Lihat di Stripe > Settings > Business > Public details > Public business name.
  STRIPE_BUSINESS_NAME: '[NAMA_BISNES_STRIPE]',

  // Matawang dalam tajuk email Stripe (RM untuk Ringgit Malaysia).
  CURRENCY: 'RM',

  // Alamat website anda (dipaparkan di bawah email).
  WEBSITE: '[URL_WEBSITE_ANDA]',

  // Berapa hari jaminan wang dikembalikan (0 = tiada ayat jaminan dalam email).
  GUARANTEE_DAYS: 7,

  // Pakej: KUNCI = jumlah bayaran dengan 2 titik perpuluhan, TEPAT seperti dalam Stripe.
  //   name  : nama pakej dalam email
  //   items : senarai apa yang pembeli dapat
  //   link  : pautan halaman muat turun (contoh terima-kasih.html?pkg=asas) atau Google Drive
  //   fileIds (pilihan): ID fail Google Drive untuk DILAMPIRKAN terus dalam email.
  //           ID ialah bahagian panjang dalam pautan Drive: drive.google.com/file/d/<ID>/view
  //           Biarkan [] jika hanya mahu hantar pautan. Saiz lampiran maksimum ±25MB.
  PAKEJ: {
    '39.00': {
      name: '[PAKEJ_1]',
      items: ['[NAMA_PRODUK]'],
      link: '[LINK_MUAT_TURUN]',
      fileIds: []
    },
    '69.00': {
      name: '[PAKEJ_2]',
      items: ['[NAMA_PRODUK]', '[BONUS]'],
      link: '[LINK_MUAT_TURUN]',
      fileIds: []
    },
    '99.00': {
      name: '[PAKEJ_3]',
      items: ['[NAMA_PRODUK]', '[BONUS]', '[ITEM_PREMIUM]'],
      link: '[LINK_MUAT_TURUN]',
      fileIds: []
    }
  },

  // Label Gmail (dicipta automatik).
  LABEL_DONE: 'produk-dihantar',      // sudah dihantar
  LABEL_SKIP: 'produk-semak-manual',  // perlu anda semak sendiri

  // Kekerapan semakan (minit). Pilihan yang dibenarkan Google: 1, 5, 10, 15, 30.
  TRIGGER_MINUTES: 5,

  // Hanya cari email Stripe dalam tempoh ini (hari).
  SEARCH_DAYS: 3,

  // Warna butang dalam email.
  BUTTON_COLOR: '#D06A48'
};

// ============================================================
// 1. PASANG: jalankan sekali sahaja
// ============================================================

/** Cipta label, cipta trigger setiap X minit, dan semak CONFIG. */
function setup() {
  checkConfig_();
  getLabel_(CONFIG.LABEL_DONE);
  getLabel_(CONFIG.LABEL_SKIP);
  // Hanya proses bayaran SELEPAS skrip dipasang. Bayaran lama anda urus sendiri.
  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('START_MS')) props.setProperty('START_MS', String(Date.now()));
  // Padam trigger lama (jika ada) supaya tidak berganda.
  removeTrigger();
  ScriptApp.newTrigger('processPayments').timeBased().everyMinutes(CONFIG.TRIGGER_MINUTES).create();
  // Pastikan fail Drive (jika ada) boleh dibaca.
  Object.keys(CONFIG.PAKEJ).forEach(function (k) {
    (CONFIG.PAKEJ[k].fileIds || []).forEach(function (id) { DriveApp.getFileById(id).getName(); });
  });
  Logger.log('Setup siap. Trigger setiap ' + CONFIG.TRIGGER_MINUTES + ' minit aktif.');
}

/** Hentikan automasi (padam trigger). */
function removeTrigger() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'processPayments') ScriptApp.deleteTrigger(t);
  });
}

// ============================================================
// 2. PROSES BAYARAN: dijalankan automatik oleh trigger
// ============================================================

function processPayments() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) return;                       // elak 2 proses serentak
  try {
    var startMs = Number(PropertiesService.getScriptProperties().getProperty('START_MS') || 0);
    var done = getLabel_(CONFIG.LABEL_DONE);
    var skip = getLabel_(CONFIG.LABEL_SKIP);
    var biz = CONFIG.STRIPE_BUSINESS_NAME;
    var query = 'from:notifications@stripe.com subject:"Payment of" subject:"for ' + biz + '" ' +
                '-label:' + CONFIG.LABEL_DONE + ' -label:' + CONFIG.LABEL_SKIP +
                ' newer_than:' + CONFIG.SEARCH_DAYS + 'd';
    var threads = GmailApp.search(query, 0, 20);

    // Corak tajuk: "Payment of RM39.00 from ali@contoh.com for Nama Bisnes"
    var cur = escRe_(CONFIG.CURRENCY), bz = escRe_(biz);
    var reEmail = new RegExp('Payment of ' + cur + '\\s?([\\d.,]+) from (\\S+@\\S+) for ' + bz, 'i');
    var reAmt   = new RegExp('Payment of ' + cur + '\\s?([\\d.,]+) from .+ for ' + bz, 'i');

    threads.forEach(function (thread) {
      var msg = thread.getMessages()[0];
      if (msg.getDate().getTime() < startMs) { thread.addLabel(skip); return; }   // bayaran lama

      var subject = msg.getSubject();
      var m = subject.match(reEmail);
      if (!m) {
        // Kadang-kadang Stripe letak NAMA pembeli dalam tajuk. Cari email di bahagian "Customer".
        var a = subject.match(reAmt);
        var cm = msg.getPlainBody().match(/Customer\s+([^\s@]+@[^\s@]+\.[a-z]{2,})/i);
        if (a && cm) m = [null, a[1], cm[1]];
      }

      // Keselamatan: pastikan email ini memang dari stripe.com (tandatangan DKIM sah).
      var authOk = /dkim=pass[^;]*header\.(i|d)=@?([a-z0-9-]+\.)*stripe\.com/i.test(msg.getRawContent());
      var amt = m ? parseFloat(String(m[1]).replace(/,/g, '')).toFixed(2) : '';
      var pkg = CONFIG.PAKEJ[amt];

      if (!m || !authOk || !pkg) {
        thread.addLabel(skip);
        Logger.log('Langkau (semak manual): ' + subject);
        if (m && authOk) {
          notifyOwner_('Semak manual: ' + subject,
            'Jumlah ' + CONFIG.CURRENCY + amt + ' tiada dalam CONFIG.PAKEJ. Hantar produk secara manual:\n' +
            'sendManual(\'' + m[2] + '\', \'39.00\')  <- tukar kepada jumlah pakej yang betul');
        } else if (!m && authOk) {
          notifyOwner_('Semak manual (tiada email pembeli): ' + subject,
            'Stripe tidak beri email pembeli dalam notifikasi ini. Cari email pembeli di Stripe > Payments, ' +
            'kemudian jalankan sendManual(\'email@pembeli.com\', \'39.00\').');
        }
        return;
      }

      var buyer = m[2].replace(/[<>.,;]+$/, '').toLowerCase();
      sendPackage_(buyer, pkg, amt);
      thread.addLabel(done);
      Logger.log('Produk dihantar kepada ' + buyer + ' (' + pkg.name + ')');
    });
  } finally {
    lock.releaseLock();
  }
}

// ============================================================
// 3. EMAIL KEPADA PEMBELI
// ============================================================

function sendPackage_(to, p, amt) {
  var rm = CONFIG.CURRENCY + amt.replace(/\.00$/, '');
  var subject = 'Pembelian anda dah sampai! ' + p.name;
  var files = (p.fileIds || []).map(function (id) { return DriveApp.getFileById(id).getBlob(); });
  var list = p.items.map(function (b, i) { return (i + 1) + '. ' + b; }).join('\n');
  var g = CONFIG.GUARANTEE_DAYS;

  // Versi teks biasa (untuk aplikasi email lama)
  var text =
    'Assalamualaikum & terima kasih kerana membeli!\n\n' +
    'Bayaran anda ' + rm + ' untuk ' + p.name + ' telah diterima. Anda dapat:\n' + list + '\n\n' +
    (files.length ? 'Fail dilampirkan dalam email ini.\n' : '') +
    'Muat turun di sini (simpan email ini):\n' + p.link + '\n\n' +
    'Tip: simpan fail ke Google Drive / Files supaya mudah dibuka semula.\n\n' +
    'Ada masalah? Balas sahaja email ini.\n\n' +
    (g ? 'Jaminan ' + g + ' hari: jika produk ini tak bermanfaat, balas email ini dalam masa ' + g + ' hari dan bayaran ' + rm + ' anda dipulangkan penuh.\n\n' : '') +
    CONFIG.SENDER_NAME + '\n' + CONFIG.WEBSITE;

  // Versi HTML (yang kebanyakan pembeli nampak)
  var btn = 'display:inline-block;background:' + CONFIG.BUTTON_COLOR + ';color:#fff;padding:14px 22px;border-radius:10px;text-decoration:none;font-weight:bold';
  var html = wrap_(
    '<p>Assalamualaikum &amp; terima kasih kerana membeli!</p>' +
    '<p>Bayaran anda <b>' + rm + '</b> untuk <b>' + esc_(p.name) + '</b> telah diterima. Anda dapat:</p>' +
    '<ol>' + p.items.map(function (b) { return '<li><b>' + esc_(b) + '</b></li>'; }).join('') + '</ol>' +
    (files.length ? '<p>&#128206; Fail juga dilampirkan dalam email ini.</p>' : '') +
    '<p><a href="' + p.link + '" style="' + btn + '">&#11015;&#65039; Muat turun sekarang</a></p>' +
    '<p style="font-size:13px;color:#666">Pautan: <a href="' + p.link + '">' + esc_(p.link) + '</a><br>' +
    'Simpan email ini. Simpan fail ke Google Drive / Files supaya mudah dibuka semula.</p>' +
    '<p>Ada masalah? Balas sahaja email ini.</p>' +
    (g ? '<p><b>Jaminan ' + g + ' hari:</b> jika produk ini tak bermanfaat, balas email ini dalam masa ' + g + ' hari dan bayaran ' + rm + ' anda dipulangkan penuh.</p>' : '') +
    '<p>' + esc_(CONFIG.SENDER_NAME) + '<br><a href="' + CONFIG.WEBSITE + '">' + esc_(CONFIG.WEBSITE) + '</a></p>');

  var opts = { htmlBody: html, name: CONFIG.SENDER_NAME };
  if (files.length) opts.attachments = files;
  GmailApp.sendEmail(to, subject, text, opts);
}

// ============================================================
// 4. FUNGSI MANUAL & UJIAN (pilih dalam menu atas, kemudian tekan Run)
// ============================================================

/** Ujian: hantar email pakej pertama ke email anda sendiri (OWNER_EMAIL). */
function testEmailKeSaya() {
  checkConfig_();
  var k = Object.keys(CONFIG.PAKEJ)[0];
  sendPackage_(CONFIG.OWNER_EMAIL, CONFIG.PAKEJ[k], k);
  Logger.log('Email ujian dihantar ke ' + CONFIG.OWNER_EMAIL + '. Semak inbox (dan folder Promotions).');
}

/**
 * Hantar secara manual. Tukar nilai di bawah, kemudian Run fungsi ini.
 * Atau panggil dari fungsi lain: sendManual('pembeli@contoh.com', '39.00')
 */
function sendManual(email, amount) {
  email = email || '[EMAIL_PEMBELI]';
  amount = amount || '39.00';
  if (email.indexOf('[') === 0) throw new Error('Tukar [EMAIL_PEMBELI] dalam fungsi sendManual dahulu.');
  var p = CONFIG.PAKEJ[amount];
  if (!p) throw new Error('Jumlah ' + amount + ' tiada dalam CONFIG.PAKEJ.');
  sendPackage_(email, p, amount);
  Logger.log('Dihantar secara manual kepada ' + email);
}

// ============================================================
// 5. FUNGSI PEMBANTU (tak perlu diubah)
// ============================================================

function checkConfig_() {
  var bad = [];
  ['SENDER_NAME', 'OWNER_EMAIL', 'STRIPE_BUSINESS_NAME', 'WEBSITE'].forEach(function (k) {
    if (/\[.*\]/.test(String(CONFIG[k]))) bad.push(k);
  });
  Object.keys(CONFIG.PAKEJ).forEach(function (k) {
    if (/\[.*\]/.test(CONFIG.PAKEJ[k].link)) bad.push('PAKEJ ' + k + ' link');
  });
  if (bad.length) throw new Error('CONFIG belum lengkap. Tukar nilai [KURUNGAN] untuk: ' + bad.join(', '));
}

function notifyOwner_(subject, body) {
  GmailApp.sendEmail(CONFIG.OWNER_EMAIL, '[Auto-email] ' + subject, body, { name: 'Auto-email ' + CONFIG.SENDER_NAME });
}

function getLabel_(name) {
  return GmailApp.getUserLabelByName(name) || GmailApp.createLabel(name);
}

function wrap_(inner) {
  return '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#222;max-width:560px">' + inner + '</div>';
}

function esc_(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escRe_(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
